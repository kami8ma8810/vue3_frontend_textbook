<template>
	<section v-pre>
		<p v-on:click="showHello">{{hello!}}</p>
	</section>
</template>
